# Portal do Grupo de Louvor — HTML para GitHub Pages

Esta versão foi adaptada para funcionar como site estático em HTML, CSS e JavaScript, sem PHP ou MySQL.

## Publicar no GitHub Pages
1. Crie um repositório no GitHub (pode ser público).
2. Envie `index.html` e este `README.md` para a raiz do repositório.
3. Em **Settings → Pages**, escolha **Deploy from a branch**, selecione `main` e `/ (root)`, e salve.
4. Aguarde a publicação e acesse a URL informada pelo GitHub.
5. Para usar um subdomínio próprio, configure-o em **Settings → Pages → Custom domain** e crie o registro DNS solicitado no painel do seu domínio.

## Acesso demonstrativo
- Líder: usuário `isaias`, senha `admin`
- Líder 2: usuário `admin2`, senha `admin`
- Integrante: usuário `membro1`, senha `123`

## Limitações importantes
- Esta é uma demonstração estática. Não há servidor, banco MySQL nem autenticação segura. As senhas de demonstração ficam no JavaScript e **não devem ser usadas para dados reais**.
- Louvores e escalas são guardados apenas no `localStorage` do navegador usado. Não sincronizam entre celulares/computadores nem entre integrantes. Limpar os dados do navegador pode apagar as alterações.
- Para um portal multiusuário real, com dados compartilhados e login seguro, é necessário um backend/API e banco de dados.

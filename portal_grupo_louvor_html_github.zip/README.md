# Portal do Grupo de Louvor — versão HTML para GitHub Pages

Esta versão foi adaptada do projeto Portal do Grupo de Louvor enviado pelo usuário para funcionar como site estático, usando **HTML, CSS e JavaScript**, sem PHP ou MySQL.

## Como publicar no GitHub Pages

1. Extraia o arquivo ZIP.
2. Crie um repositório no GitHub, por exemplo `portal-grupo-louvor`.
3. Envie `index.html` e `README.md` para a raiz do repositório.
4. Abra **Settings → Pages**.
5. Em **Build and deployment**, selecione **Deploy from a branch**, branch `main`, pasta `/ (root)`, e salve.
6. Aguarde a publicação e abra o endereço indicado pelo GitHub Pages.

## Acessos demonstrativos

- Líder: usuário `isaias`, senha `admin`
- Líder 2: usuário `admin2`, senha `admin`
- Integrante: usuário `membro1`, senha `123`

Há outros usuários de demonstração (`admin3` e `membro2` até `membro12`).

## Limitações importantes

- GitHub Pages não executa PHP nem oferece banco de dados MySQL. Esta adaptação usa `localStorage` do navegador para guardar louvores, escalas e usuários.
- Os dados só ficam disponíveis no navegador/dispositivo em que foram cadastrados. Não são compartilhados automaticamente entre integrantes.
- O login e as senhas são apenas demonstrativos e podem ser vistos/modificados por alguém que inspecione o código ou os dados do navegador. **Não use esta versão para informações sensíveis ou como sistema real multiusuário.**
- O projeto inclui cadastro local de usuários, sugestão de louvores, relatório master, escala de cultos, presença, programação de repertório e exportação de relatório de frequência em PDF.

Para dados sincronizados entre todos os integrantes e autenticação segura, será necessário manter um backend/API e banco de dados numa hospedagem que suporte PHP/MySQL, ou migrar para um serviço de backend compatível.
